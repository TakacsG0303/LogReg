package com.example.logreg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button bt_bej,bt_reg;
    EditText et_felh,et_jelsz;
    public int bejelentkezette=0;
    dbhelper adatbazisSegito;

    public void init() {
        bt_bej = findViewById(R.id.bt_bej);
        bt_reg = findViewById(R.id.bt_reg);
        et_felh = findViewById(R.id.et_felh);
        et_jelsz = findViewById(R.id.et_jelsz);



       // bejelentkezette = 0; //false
        adatbazisSegito = new dbhelper(MainActivity.this);


        SharedPreferences sharedPreferences = getSharedPreferences("bejelentkezetteSH", Context.MODE_PRIVATE);
       SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("bejelentkezette2",0);
        editor.apply();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        bt_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(intent);
                finish();
            }
        });

        bt_bej.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(et_felh.getText().toString().equals("") || et_jelsz.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Nem maradhat üresen egy mező sem.", Toast.LENGTH_SHORT).show();
                }
                else  {

                    /*
                  boolean sikerese=  adatbazisSegito.bejelentkezessikeres(et_felh.getText().toString(),et_jelsz.getText().toString());
                  if (sikerese==true) {
                      bejelentkezette=1;
                      Intent intent = new Intent(MainActivity.this,LoggedInActivity.class);
                      startActivity(intent);
                      finish();
                  }else {
                      Toast.makeText(MainActivity.this, "Sikertelen bejelentkezés.", Toast.LENGTH_SHORT).show();
                  }
                         */
                Cursor eredmeny = adatbazisSegito.bejelentkezeskeres(et_felh.getText().toString(),et_jelsz.getText().toString());
                if (eredmeny!=null&&eredmeny.getCount()>0) {
                    bejelentkezette=1;
                    Intent intent = new Intent(MainActivity.this,LoggedInActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    Toast.makeText(MainActivity.this, "Sikertelen bejelentkezés.", Toast.LENGTH_SHORT).show();
                }


                }

            }
        });















    }
}
