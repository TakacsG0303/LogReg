package com.example.logreg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ActivityChooserView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class LoggedInActivity extends AppCompatActivity {

    Button bt_kij;
    TextView tw_adatok;
    dbhelper adatbazisSegito;

    public void init() {
    bt_kij = findViewById(R.id.bt_kij);
    tw_adatok = findViewById(R.id.tw_adatok);
    adatbazisSegito = new dbhelper(LoggedInActivity.this);
    }

    public void adatoklistaz() {
       Cursor eredmeny = adatbazisSegito.adatLekerdezes();
        StringBuffer stringBuffer = new StringBuffer();
        if (eredmeny!=null&&eredmeny.getCount()>0)
        {
            while (eredmeny.moveToNext())
            {
                stringBuffer.append("Felhasznűló név:"+eredmeny.getString(0)+"\n");
                stringBuffer.append("Teljes Náv :"+eredmeny.getString(1)+"\n");

            }
            tw_adatok.setText(stringBuffer.toString());
            Toast.makeText(this, "Sikeres adatlekérdezés", Toast.LENGTH_SHORT).show();
        }
        
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_in);

        init();

        bt_kij.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoggedInActivity.this,MainActivity.class);
                startActivity(intent);
                finish();

            }
        });

        adatoklistaz();








    }
}
