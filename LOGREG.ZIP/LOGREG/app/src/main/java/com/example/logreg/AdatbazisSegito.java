package com.example.logreg;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AdatbazisSegito extends SQLiteOpenHelper {

    private static final int DBversion = 1;
    private static final String DBname="users.db";
    private static final  String TABLE_NAME = "felhasznalo";
    private static final  String COL_ID = "id";
    private static final  String COL_EMAIL = "email";
    private static final  String COL_FELHNEV = "felhasznalonev";
    private static final  String COL_JELSZO = "jelszo";
    private static final  String COL_TELJESNEV = "teljesnev";

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTables = "CREATE TABLE IF NOT EXISTS "+TABLE_NAME+"("+
                COL_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                COL_EMAIL+" VARCHAR(30),"+
                COL_FELHNEV+" VARCHAR(30),"+
                COL_JELSZO+" VARCHAR(30),"+
                COL_TELJESNEV+" VARCHAR(30))";
        db.execSQL(createTables);
    }

    public AdatbazisSegito(Context context){
        super(context,DBname,null,DBversion);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public boolean adatFelvetel(String email, String felhnev, String jelszo,String teljesnev){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EMAIL, email);
        values.put(COL_FELHNEV, felhnev);
        values.put(COL_JELSZO, jelszo);
        values.put(COL_TELJESNEV, teljesnev);

        //return db.insert(TABLE_NAME, null, values) != -1;
        long erintettSorok = db.insert(TABLE_NAME, null, values);
        if (erintettSorok == -1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor adatLekerdezes(){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT "+COL_FELHNEV+", "+COL_TELJESNEV+" FROM "+TABLE_NAME, null);
    }

    public Cursor bejelentkezeskeres(String felhnev, String jelszo){
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM "+ TABLE_NAME +" WHERE " +COL_FELHNEV+ " = felhnev AND "+COL_JELSZO+"= jelszo";
        return db.rawQuery(sql, new String[] {felhnev,jelszo});
    }
    public boolean bejelentkezessikeres(String felhnev,String jelszo) {

          /*
                    $like = "";
                    if(isset($_GET["keresendo_szo"]) and !empty($_GET["keresendo_szo"])
                        ){
                        $like = " WHERE tanar_nev LIKE '%".$_GET["keresendo_szo"]."%' OR
                                        tanar_pontszam  LIKE '%".$_GET["keresendo_szo"]."%'
                        ";

                        $this->sql = "SELECT
                        tanar_id,
                        tanar_nev,
                        tanar_pontszam
                        FROM
                        tanarok" . $like;
                     */
        SQLiteDatabase db = this.getReadableDatabase();
        String sql ="SELECT * FROM "+TABLE_NAME+" WHERE "+COL_FELHNEV+" LIKE "+felhnev+" AND "+COL_JELSZO;
        return true;
    }

}
