package com.example.logreg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText et_email,et_felhasz,et_jelszo,et_teljnev;
    Button bt_regiszt,bt_vissza;
    dbhelper adatbazisSegito;

    public void init() {
        et_email= findViewById(R.id.et_email);
        et_felhasz= findViewById(R.id.et_felhasz);
        et_jelszo= findViewById(R.id.et_jelszo);
        et_teljnev= findViewById(R.id.et_teljnev);

        bt_regiszt= findViewById(R.id.bt_regiszt);
        bt_vissza= findViewById(R.id.bt_vissza);
        adatbazisSegito = new dbhelper(RegisterActivity.this);
    }

    public void regisztracio() {
        String email= et_email.getText().toString();
        String felhnev = et_felhasz.getText().toString();
        String jelszo = et_jelszo.getText().toString();
        String tejlnev = et_teljnev.getText().toString();
        boolean eredmeny = adatbazisSegito.adatFelvetel(email,felhnev,jelszo,tejlnev);

        if (email.equals("")||felhnev.equals("")||jelszo.equals("")||tejlnev.equals("")) {
            Toast.makeText(this, "Nem maradhat üresen egy mező sem.", Toast.LENGTH_SHORT).show();
        }
        else {
            if (eredmeny) {

                Toast.makeText(this, "Sikeres felvétel", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Nem sikerült felvenni az adatokat", Toast.LENGTH_SHORT).show();
            }
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        init();

        bt_vissza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        bt_regiszt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regisztracio();
            }
        });



    }
}
